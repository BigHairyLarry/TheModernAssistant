import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "The Modern Assistant — Automation • AI Agents • Growth",
  description: "AI that books, follows up, and closes — while you sleep.",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}