"use client";
import React from "react";
import { motion } from "framer-motion";
import { Button } from "@/components/ui/Button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/Card";
import { Input } from "@/components/ui/Input";
import { Textarea } from "@/components/ui/Textarea";
import { Badge } from "@/components/ui/Badge";
import { Check, Zap, Bot, Presentation, Wand2, LineChart, ShieldCheck, PlugZap, PhoneCall, Rocket } from "lucide-react";

const features = [
  { icon: <Bot className="h-6 w-6" aria-hidden />, title: "AI Chat & Support", desc: "24/7 website concierge that books, answers FAQs, and captures qualified leads." },
  { icon: <PlugZap className="h-6 w-6" aria-hidden />, title: "Workflow Automations", desc: "Connect calendars, CRMs, and forms to eliminate busywork across the stack." },
  { icon: <Wand2 className="h-6 w-6" aria-hidden />, title: "Content On Autopilot", desc: "Shorts, posts, and emails generated, scheduled, and tracked for performance." },
  { icon: <ShieldCheck className="h-6 w-6" aria-hidden />, title: "Safe & Compliant", desc: "Guardrails and approvals so nothing goes live without your say-so." },
];

const plans = [
  { name: "Starter", price: "$1,500 setup + $249/mo", badge: "Great for solopreneurs", features: ["1 AI chat concierge","Lead capture + email alerts","1 automated pipeline (e.g., intake → CRM)","Monthly analytics snapshot","Email support"] },
  { name: "Growth", price: "$3,500 setup + $549/mo", badge: "Most popular", features: ["Everything in Starter","Multi-channel content engine","Calendar + booking automations","2 custom agents (sales + service)","Quarterly strategy workshop"] },
  { name: "Scale", price: "Custom", badge: "For teams", features: ["Done-for-you funnels","CRM + SMS integrations","Sales enablement dashboards","Dedicated success manager","Priority support"] },
];

const faqs = [
  { q: "How fast can we launch?", a: "Most Starter launches happen in 7–14 days once assets are approved." },
  { q: "Do you work with regulated industries?", a: "Yes. We implement review/approval flows and keep content within platform guidelines." },
  { q: "What tools do you integrate?", a: "Airtable, HubSpot, Salesforce, ClickUp, Google Workspace, Calendly, Shopify, TikTok Shop, and more." },
  { q: "What’s your guarantee?", a: "If we don’t deliver the agreed scope, we work for free until it’s right." },
];

export default function Page() {
  return (
    <div className="min-h-screen">
      <header className="sticky top-0 z-40 bg-white/70 backdrop-blur border-b">
        <div className="container py-3 flex items-center justify-between">
          <a href="#home" className="flex items-center gap-2">
            <div className="h-9 w-9 rounded-2xl bg-slate-900 text-white grid place-items-center font-bold">MA</div>
            <span className="font-semibold tracking-tight">The Modern Assistant</span>
          </a>
          <nav className="hidden md:flex items-center gap-6 text-sm">
            <a href="#features" className="hover:text-slate-700">Features</a>
            <a href="#services" className="hover:text-slate-700">Services</a>
            <a href="#pricing" className="hover:text-slate-700">Pricing</a>
            <a href="#work" className="hover:text-slate-700">Work</a>
            <a href="#faq" className="hover:text-slate-700">FAQ</a>
          </nav>
          <div className="flex items-center gap-3">
            <Button className="btn-outline" asChild><a href="#contact">Contact</a></Button>
            <Button className="">Book a Demo</Button>
          </div>
        </div>
      </header>

      <section id="home" className="relative">
        <div className="container py-20 md:py-28 grid md:grid-cols-2 gap-10 items-center">
          <motion.div initial={{ opacity: 0, y: 10 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ duration: 0.6 }} className="space-y-6">
            <Badge><Zap className="h-4 w-4" /> Automate the busywork</Badge>
            <h1 className="text-4xl md:text-6xl font-extrabold leading-tight tracking-tight">
              AI that books, follows up, and closes — <span className="text-slate-500">while you sleep.</span>
            </h1>
            <p className="text-lg md:text-xl text-slate-600 max-w-xl">
              The Modern Assistant builds automations, chat agents, and content engines that turn browsers into booked calls and revenue.
            </p>
            <div className="flex flex-wrap gap-3">
              <Button className="" asChild><a href="#contact"><Rocket className="h-5 w-5 mr-2" /> Get Proposal</a></Button>
              <Button className="btn-outline" asChild><a href="#work"><Presentation className="h-5 w-5 mr-2" /> See Work</a></Button>
            </div>
            <div className="flex items-center gap-6 pt-4 text-sm text-slate-500">
              <div className="flex items-center gap-2"><Check className="h-4 w-4"/> No long contracts</div>
              <div className="flex items-center gap-2"><Check className="h-4 w-4"/> Approvals on everything</div>
              <div className="flex items-center gap-2"><Check className="h-4 w-4"/> Real ROI reporting</div>
            </div>
          </motion.div>

          <motion.div initial={{ opacity: 0, y: 10 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ duration: 0.6, delay: 0.1 }}>
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center gap-2"><PhoneCall className="h-5 w-5"/> Free 20‑min Audit Call</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <p className="text-slate-600 text-sm">Tell us about your business. We’ll map the quickest path to measurable wins.</p>
                <form className="space-y-3" onSubmit={(e)=>{e.preventDefault(); alert('Thanks! We will reach out shortly.')}}>
                  <Input placeholder="Name" required />
                  <Input type="email" placeholder="Email" required />
                  <Input placeholder="Company / Website" />
                  <Textarea placeholder="What do you want to automate or grow?" rows={4} />
                  <Button className="w-full" type="submit">Request Audit</Button>
                  <p className="text-[11px] text-slate-500">By submitting, you agree to be contacted about services. No spam. Opt out anytime.</p>
                </form>
              </CardContent>
            </Card>
          </motion.div>
        </div>
      </section>

      <section className="py-8">
        <div className="container">
          <div className="text-center text-sm text-slate-500 mb-6">Trusted by operators in</div>
          <div className="grid grid-cols-2 md:grid-cols-6 gap-6 items-center opacity-70">
            {Array.from({ length: 6 }).map((_, i) => (<div key={i} className="h-10 rounded-xl bg-slate-200" />))}
          </div>
        </div>
      </section>

      <section id="features" className="py-16 md:py-24">
        <div className="container">
          <div className="max-w-2xl mb-10">
            <h2 className="text-3xl md:text-4xl font-bold tracking-tight">What you get on day one</h2>
            <p className="text-slate-600 mt-3">Concrete deliverables that move the needle. No fluff, just results.</p>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {features.map((f) => (
              <Card key={f.title}>
                <CardHeader>
                  <div className="h-11 w-11 rounded-2xl bg-slate-900 text-white grid place-items-center mb-3">{f.icon}</div>
                  <CardTitle className="text-lg">{f.title}</CardTitle>
                </CardHeader>
                <CardContent>{f.desc}</CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      <section id="services" className="py-16 bg-white">
        <div className="container">
          <div className="max-w-2xl mb-10">
            <h2 className="text-3xl md:text-4xl font-bold tracking-tight">Services that stack</h2>
            <p className="text-slate-600 mt-3">Mix and match deliverables — we’ll architect the system around your goals.</p>
          </div>
          <div className="grid lg:grid-cols-3 gap-6">
            <Card>
              <CardHeader><CardTitle className="flex items-center gap-2"><Bot className="h-5 w-5"/> Conversational Agents</CardTitle></CardHeader>
              <CardContent><ul className="space-y-2">
                <li className="flex gap-2"><Check className="h-4 w-4 mt-0.5"/> Lead-qualifying website bot</li>
                <li className="flex gap-2"><Check className="h-4 w-4 mt-0.5"/> Sales follow-up via email/SMS</li>
                <li className="flex gap-2"><Check className="h-4 w-4 mt-0.5"/> Knowledge-base ingestion</li>
              </ul></CardContent>
            </Card>

            <Card>
              <CardHeader><CardTitle className="flex items-center gap-2"><Wand2 className="h-5 w-5"/> Content & Social Engine</CardTitle></CardHeader>
              <CardContent><ul className="space-y-2">
                <li className="flex gap-2"><Check className="h-4 w-4 mt-0.5"/> Shorts/TikTok auto-edit + captions</li>
                <li className="flex gap-2"><Check className="h-4 w-4 mt-0.5"/> Posts scheduled across channels</li>
                <li className="flex gap-2"><Check className="h-4 w-4 mt-0.5"/> Weekly ideas & prompts</li>
              </ul></CardContent>
            </Card>

            <Card>
              <CardHeader><CardTitle className="flex items-center gap-2"><LineChart className="h-5 w-5"/> Funnels & Analytics</CardTitle></CardHeader>
              <CardContent><ul className="space-y-2">
                <li className="flex gap-2"><Check className="h-4 w-4 mt-0.5"/> Lead forms → CRM pipelines</li>
                <li className="flex gap-2"><Check className="h-4 w-4 mt-0.5"/> KPI dashboards & call booking</li>
                <li className="flex gap-2"><Check className="h-4 w-4 mt-0.5"/> A/B tests & growth loops</li>
              </ul></CardContent>
            </Card>
          </div>
        </div>
      </section>

      <section id="work" className="py-16 md:py-24">
        <div className="container">
          <div className="max-w-2xl mb-10">
            <h2 className="text-3xl md:text-4xl font-bold tracking-tight">Recent wins</h2>
            <p className="text-slate-600 mt-3">A peek at outcomes we engineered. Replace with real case studies when ready.</p>
          </div>
          <div className="grid md:grid-cols-3 gap-6">
            {[1,2,3].map((i) => (
              <Card key={i}>
                <div className="h-40 bg-gradient-to-br from-slate-200 to-slate-100" />
                <CardHeader><CardTitle>Case Study {i}</CardTitle></CardHeader>
                <CardContent className="space-y-2">
                  <p>Implemented inbound bot + booking flow, reducing response time by 93%.</p>
                  <ul className="space-y-1">
                    <li className="flex gap-2"><Check className="h-4 w-4 mt-0.5"/> +38% qualified leads</li>
                    <li className="flex gap-2"><Check className="h-4 w-4 mt-0.5"/> 2.1× demo conversions</li>
                    <li className="flex gap-2"><Check className="h-4 w-4 mt-0.5"/> Payback in 32 days</li>
                  </ul>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      <section id="pricing" className="py-16 bg-white">
        <div className="container">
          <div className="max-w-2xl mb-10">
            <h2 className="text-3xl md:text-4xl font-bold tracking-tight">Pricing</h2>
            <p className="text-slate-600 mt-3">Transparent packages with room to customize. Financing available on request.</p>
          </div>
          <div className="grid md:grid-cols-3 gap-6">
            {plans.map((p) => (
              <Card key={p.name}>
                <CardHeader>
                  <div className="flex items-center justify-between">
                    <CardTitle>{p.name}</CardTitle>
                    <span className="badge">{p.badge}</span>
                  </div>
                  <div className="text-2xl font-bold mt-2">{p.price}</div>
                </CardHeader>
                <CardContent>
                  <ul className="space-y-2">
                    {p.features.map((f) => (<li key={f} className="flex gap-2"><Check className="h-4 w-4 mt-0.5"/> {f}</li>))}
                  </ul>
                  <div className="mt-5"><Button className="w-full">Choose {p.name}</Button></div>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      <section className="py-12">
        <div className="container">
          <div className="rounded-3xl border p-8 md:p-10 flex flex-col md:flex-row items-start md:items-center justify-between gap-6 bg-white">
            <div>
              <h3 className="text-2xl font-bold">Ready to free up 20+ hours a week?</h3>
              <p className="text-slate-600 mt-1">Let’s map what to automate first and what will print revenue.</p>
            </div>
            <Button className="" asChild><a href="#contact">Get My Audit</a></Button>
          </div>
        </div>
      </section>

      <section id="faq" className="py-16 bg-white">
        <div className="container max-w-5xl">
          <h2 className="text-3xl md:text-4xl font-bold tracking-tight mb-8">FAQ</h2>
          <div className="grid md:grid-cols-2 gap-6">
            {faqs.map((item) => (
              <Card key={item.q}>
                <CardHeader><CardTitle className="text-lg">{item.q}</CardTitle></CardHeader>
                <CardContent>{item.a}</CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      <section id="contact" className="py-16">
        <div className="container max-w-5xl">
          <div className="grid md:grid-cols-2 gap-8">
            <div>
              <h2 className="text-3xl md:text-4xl font-bold tracking-tight">Let’s build your assistant</h2>
              <p className="text-slate-600 mt-3">Tell us about your goals and existing tools. We’ll send a scoped proposal within 24 hours.</p>
              <div className="mt-6 grid grid-cols-2 gap-4 text-sm text-slate-600">
                <div className="flex items-center gap-2"><ShieldCheck className="h-4 w-4"/> Contract‑free options</div>
                <div className="flex items-center gap-2"><Zap className="h-4 w-4"/> Rapid setup</div>
                <div className="flex items-center gap-2"><LineChart className="h-4 w-4"/> KPI tracking</div>
                <div className="flex items-center gap-2"><Wand2 className="h-4 w-4"/> Content engine</div>
              </div>
            </div>
            <Card>
              <CardHeader><CardTitle>Contact us</CardTitle></CardHeader>
              <CardContent>
                <form className="space-y-3" onSubmit={(e)=>{e.preventDefault(); alert('Message sent!')}}>
                  <Input placeholder="Full name" required />
                  <Input type="email" placeholder="Work email" required />
                  <Input placeholder="Company" />
                  <Textarea placeholder="What problem should we solve first?" rows={4} />
                  <Button className="w-full" type="submit">Send</Button>
                  <p className="text-[11px] text-slate-500">We’ll reply within one business day.</p>
                </form>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      <footer className="border-t py-10 bg-white">
        <div className="container flex flex-col md:flex-row items-start md:items-center justify-between gap-6">
          <div className="flex items-center gap-3">
            <div className="h-8 w-8 rounded-xl bg-slate-900 text-white grid place-items-center text-xs font-bold">MA</div>
            <div>
              <div className="font-semibold">The Modern Assistant</div>
              <div className="text-xs text-slate-500">Automation • AI Agents • Growth</div>
            </div>
          </div>
          <div className="text-sm text-slate-500">© {new Date().getFullYear()} The Modern Assistant. All rights reserved.</div>
        </div>
      </footer>
    </div>
  );
}