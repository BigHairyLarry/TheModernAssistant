import React from "react";
export function Button({ className = "", variant, size, asChild, ...props }:
  React.ButtonHTMLAttributes<HTMLButtonElement> & { className?: string; variant?: "outline"|"ghost"|undefined; size?: "lg"|undefined; asChild?: boolean }) {
  const classes = ["btn", variant === "outline" ? "btn-outline" : "", size === "lg" ? "px-5 py-3 text-base" : "", className].join(" ");
  if (asChild) {
    const { children, ...rest } = props as any;
    return React.cloneElement(children as any, { className: classes, ...rest });
  }
  return <button className={classes} {...props} />;
}